/////////////////////////////////////////////////////////////////////////
// 					   Video Controller
// 						J. Arias (2025)
//
// VESA 640x480 timing

module video ( 
	input clk,		// clock input @ 25MHz
	input [31:0]d,	// data input
	output [11:0]va,	// address (changed from 14 to 12 bits)
	output vrd,		// video read
	output reg hsyn,	// horizontal sync
	output reg vsyn,	// vertical sync
	output reg hde,		// horizontal display enable
	output reg vde,		// vertical display enable
	output video,	// 1bpp output
	input  text,	// text mode if 1
	input  h2x,		// duplicate pixels
	input  v2x,		// duplicate lines
	output reg [9:0]hc,	// Horiz. counter (for PWM)
	output reg hde0		// horizontal display enable (wo delay)
);

//////////////////// VGA timing //////////////////////
wire hmax = &(hc |(~10'd799));

always @(posedge clk) begin
	hc <= hmax ? 0 : hc+1;
	if (hc==10'd655-2) hsyn<=0;
	if (hc==10'd751-2) hsyn<=1;
	hde0 <= hmax ? 1 : ((hc==10'd639) ? 0 : hde0);
end

reg [9:0]vc=0;	// Vertical counter
wire vmax = &(vc |(~10'd524));

always @(posedge clk) if (hmax) begin
	vc<= vmax? 0 : vc+1;
	vde<= vmax ? 1 : ((vc==10'd479) ? 0 : vde);
	if (vc==10'd489) vsyn<=0;
	if (vc==10'd491) vsyn<=1;
end

///////////////////// Video Read & address ///////////////////

assign vrd = hde0 & vde & ({hc[5]&h2x,hc[4:0]}==0); // video memory read (32 bits)
wire brd = hde0 & vde & ({hc[3]&h2x,hc[2:0]}==0);	// byte read
// va = vc * 20 + hc/32
// va = vc * 10 + hc/64	// pixels doubled
// va = vc/2 *...		// lines doubled
// va = vc/8 *...		// Text
// va = vc/16 *...		// Text, lines doubled
wire [8:0]vcm = v2x ? {1'b0,vc[8:1]} : vc[8:0];	 // Vert. counter modiffied
wire [8:0]vcmt = text ? {3'b000,vcm[8:3]} : vcm; // Vert. counter modiffied for text

// FIX: Changed from 14 bits to 12 bits for all intermediate calculations
wire [11:0]vva0 = {vcmt[8:0],3'b000} + {vcmt[8:0],1'b0}; 	 // vc_mod * 10
wire [11:0]vva1 = h2x ? vva0 : {vva0[10:0],1'b0}; // pixels not doubled (vc_mod * 20)
assign va = vva1 + (h2x ? {6'b0,hc[9:6]} : {5'b0,hc[9:5]});

///////////////////// Pixel shift /////////////////////
reg [23:0]vbuf;		// 32-bit buffering (24 bits MSB)
always @(posedge clk) vbuf<= vrd ? d[31:8] : (brd ? {8'h00,vbuf[23:8]} : vbuf);
wire [7:0]vbyte = vrd ? d[7:0] : vbuf[7:0];

// character ROM (asynchronous ROM: lots of LCs)
reg [7:0]grom[0:1023];
initial $readmemh("character.list", grom);
wire [7:0]charout = grom[{vbyte[6:0],vcm[2:0]}];
wire [7:0]charinv = vbyte[7] ? ~charout : charout; // inverted text

// FI vga first column: 2 steps pipeline for the shifter
reg [7:0]sh;
wire shen = (~h2x) | (~hc[0]); // shift enable (if pixels doubled)

always @(posedge clk) begin
	if (brd) 
	    sh <= text ? charinv : vbyte;
	else 
	    if (shen) sh <= {1'b0, sh[7:1]};
end
// output 
assign video = sh[0];

// delayed hde 
always @(posedge clk) begin
    hde <= hde0;
end

initial begin
	hc = 0;
	hsyn = 1;
	hde0 = 1;
	vsyn = 1;
	vde = 1;
	sh = 0;
	hde = 1;
end

endmodule
