module spi_simple(
	input	clk,
	input	we,		// write strobe
	input	[7:0]d,	// data to send
	output	[7:0]q,	// received data
	input 	fast,	// 1: SCK=clk   0: SCK=clk/256
	output	busy,	// 1 while tx/rx

	output	sck,
	output	mosi,
	input	miso
);

reg [7:0]sdiv=0;
always @(negedge clk) sdiv<=we ? 0 : sdiv+1;
reg [7:0]q;
reg [3:0]cntbusy=4'd15;
reg sin;
wire spicke;
wire busy;
assign spicke=(&sdiv) | fast;
assign busy=~cntbusy[3];

always @(negedge clk ) begin
	if (we) begin q<=d; cntbusy<=0; end
	else if (spicke & busy) begin
			q<={q[6:0],smiso};
			cntbusy<=cntbusy+busy;
		end
end

assign sck=fast? (busy&clk) : (busy&sdiv[7]);
assign mosi=q[7];

//	reg smiso;	// MISO sampled at SCK rising edges
//	always @(posedge sck) miso<=miso;
wire smiso = miso;

endmodule

