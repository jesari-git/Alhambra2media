
#include <stdint.h>
typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;

typedef signed char  s8;
typedef signed short s16;
typedef signed int   s32;
#define NULL ((void *)0)

#define FFT

int16_t offset,gain;	// variables globales

#ifdef FFT
	#define L2NS (9)
	#define NSAMPLES (1<<L2NS)

	#include "fixfft.c"
#endif

#include "system.h"

//////////////////////////////////////////////////////////////////
// Serial console
void _putch(int c)
{
	while((UARTSTA & TXRDY)==0);
	//if (c == '\n') _putch('\r');
	UARTDAT = c;
}

void _puts(const char *p)
{
	while (*p)
		_putch(*(p++));
}

uint8_t _getch()
{
	while((UARTSTA & RXVAL)==0);
	return UARTDAT;
}

#define putchar(d) _putch(d)
//#define getchar() _getch()

uint32_t kcola;	// pending characters

int getchar()
{
	uint32_t d;
	d=kcola;
	if (d) {
		kcola=d>>8;
		return d&0xff;
	}
	return _getch();
}

#include "printf.c"

//////////////////////////////////////////////////////////////////
// SD CARD / FAT Filesystem

// SPI transfer (8-bits)
uint32_t spixfer (uint32_t d)
{
	SPI=d;
	while(STATUS & SPIBUSY);
	return SPI;
}

// SD init, commands, block read
#define FASTBLK
#include "sdspi.c"

// FAT16 / FAT32 management
#define rdsector(a,b) SD_read_Block(a,b)
#include "fat32.c"

// Interactive file selection
#include "fnav.c"

//////////////////////////////////////////////////////////////////
// support routines
void clearscr() {_puts("\033[2J\033[H");}

//////////////////////////////////////////////////////////////////
// AUDIO PLAYBACK
volatile int8_t stereo,repe=1; // flag
volatile int16_t ardix;	// Audio Read index (negative means muted)
int16_t abuf[512];		// double buffer (2 x 256 samples)

// ADC interrupt (DAC samples are synchronous with ADC's)
void __attribute__((interrupt ("machine"))) ADC_handler()
{
	int i,d;
	static uint8_t repint=1;
	i=ardix;
	if (i>=0) {					// playing index positive
		if (stereo) {
			d=abuf[i++];
			d+=abuf[i++];
			d>>=5;
			i&=~1;
		}else{
			d=abuf[i];
			d>>=4;
			i++;
		}
		DAC=d+2048;
		if (d<00) d=-d; 			// VU-meter (sort of)
		GPOUT=d>>3; FGCOLOR=d>>5;	
		if(--repint==0) {
			repint=repe;
			i&=511;			// update audio read index
			ardix=i;
		}
	}
	i=ADC;			// Clear IRQ flag
}


//////// rutinas modo gráfico 320x240 //////
uint32_t fbuf[9600/4];

void cls()
{
	int i;
	for (i=0;i<9600/4;i++) fbuf[i]=0;
}

void putpixel(uint32_t x, uint32_t y, uint32_t pix)
{
	int i,b;
	if (y>239) y=239;
	if (x>319) x=319;
	
	i=y*10+(x>>5);
	b=1<<(x&31);
	if (pix) fbuf[i]|=b;
	else fbuf[i]&=~b;
}

void clearallvline(uint32_t x)
{
	int i,b;
	if (x>319) x=319;
	i=(x>>5);
	b=~(1<<(x&31));
	for (;i<240*10;i+=10) fbuf[i]&=b;
}

void setvline(uint32_t x,uint32_t y1, uint32_t y2)
{
	int i,j,b;
	if (y2>239) y2=239;
	if (x>319) x=319;
	
	i=y1*10+(x>>5);
	j=i+(y2-y1)*10;
	b=(1<<(x&31));
	for (;i<=j;i+=10) fbuf[i]|=b;
}

void clearvline(uint32_t x,uint32_t y1, uint32_t y2)
{
	int i,j,b;
	if (y2>239) y2=239;
	if (x>319) x=319;
	
	i=y1*10+(x>>5);
	j=i+(y2-y1)*10;
	b=~(1<<(x&31));
	for (;i<=j;i+=10) fbuf[i]&=b;
}
#include "music-icon.xbm"

void putxbm(uint8_t *pdata, int szx, int szy)
{
	uint8_t *pfb;
	int i,j,ox,oy,msk;

	cls();
	
	ox=(320-szx)/2;
	oy=(240-szy)/2;
	pfb=(uint8_t *)fbuf; pfb=&pfb[oy*40+ox/8];
	msk=0xff>>(8-(szx&7));
	szx=(szx+7)>>3;

	for (i=0;i<szy;i++) {
		for (j=0;j<szx;j++) *pfb++=*pdata++;
		if (msk) pfb[-1]&=msk;
		pfb=&pfb[40-szx];
	}
} 

//////// lectura ADC //////
uint32_t get_ADC()
{
//	while ((STATUS & ADCIRQ)==0);
	asm volatile("WFI");
	return ADC; // y borra ADCIRQ
}

uint32_t get_ADC_proc()
{	
	int32_t v;
	v=(get_ADC()-2048-offset)<<gain;
	v+=2048;
	if (v<0) v=0;
	if (v>4095) v=4095;
	return v;
}

//////////////////////////////////////////////////////////////////
// PSRAM
void ramread(int addr, char *buf, int nb){
	CONTROL &= ~CSPS;
	spixfer(0x03);
	spixfer(addr>>16);
	spixfer(addr>>8);
	spixfer(addr);
	for (;nb;nb--) *buf++=spixfer(0);
	CONTROL |= CSPS;
}

void ramwrite(int addr, char *buf, int nb){
	CONTROL &= ~CSPS;
	spixfer(0x02);
	spixfer(addr>>16);
	spixfer(addr>>8);
	spixfer(addr);
	for (;nb;nb--) spixfer(*buf++);
	CONTROL |= CSPS;
}

void ramid(char *buf){
	int i;
	CONTROL &= ~CSPS;
	spixfer(0x9f);
	spixfer(0);
	spixfer(0);
	spixfer(0);
	for (i=0;i<8;i++) *buf++=spixfer(0);
	CONTROL |= CSPS;
}

void hdump (char *pdata, int base, int nl)
{
	int i,j,k;
	for(i=0;i<nl;i++) {
		_printf("%08x  ",base+i*16);
		
		for (j=0;j<16;j++) _printf("%02x ",pdata[i*16+j]);
		_puts("  ");
		for (j=0;j<16;j++) {
			k=pdata[i*16+j];
			_putch((k>31 && k<128)?k:'.');
		}
		_putch('\n');
	}
}

void _memcpy(uint8_t *pd,uint8_t*ps,int sz)
{
	for (;sz;sz--) *pd++=*ps++;
}

void _memset(uint8_t *pd, int d,int sz)
{
	for (;sz;sz--) *pd++=d;
}

void _memset32(uint32_t *pd, int d,int sz)
{
	for (;sz;sz--) *pd++=d;
}

//////////////////////////////////////////////////////////////////
// MAIN
void main()
{
	int i,j,n,ff,v1,v2,dir,flen,k,wrix;
	uint8_t *p;
	uint32_t *pi;
	uint16_t *ps;
	char *fext[]={"WAV",NULL};
#ifdef FFT
	static fixed far[NSAMPLES],fai[NSAMPLES];
#else
	static uint16_t far[321];
#endif
	static uint8_t buf[256];

init:

	CONTROL=CSSD | CSPS | MODE7;
	BGCOLOR=0x005;
	FGCOLOR=0x02C;
	DAC=2048; ardix=-1; kcola=0;

	IRQVECT6 = (uint32_t)ADC_handler;
	IRQEN|=ENIRQ_ADC;
	
	VBASE=(uint32_t )fbuf;
	ff=0; offset=0; gain=0; 

	p=(uint8_t *)fbuf;
	_memset32(fbuf,0x20202020,40*30/4);
	_memcpy(&p[15*40+20-3],"Select",6);

	while (1) {
		_puts("\nSelect:\n1 - WAV player from SD card\n\n2 - Oscope / FFT\n\n3 - PSRAM test\n");
		i=_getch();
		if (i=='1') break;
		if (i=='2') goto adcplay;
		if (i=='3') goto psramtst;
	}
	
	_puts("\nFAT32 navigator / WAV player\n");
	CONTROL=CSSD | CSPS | MODE3;
	FGCOLOR=0x02C;
	ardix=-1;
	GPOUT=0;
	putxbm((uint8_t *)icon_bits, icon_width, icon_height);

sdinit:
	_delay_ms(500);
	i=UARTDAT;		// flush RX
	i=SD_init();
	if (i) {_printf("Error sd_init (%d)\n",i); goto sdinit; }
	if (i=initFAT()) {_printf("Error FAT: %d\n",i); goto sdinit; }
	FATvar.cur_dir_cluster=FATvar.root_cluster;
	while (1)
	{
		// if autoplay (kcola!=0) stop if same file selected
		i=(kcola)?sel:-1;
		p=file_select((u8 **)fext,"Select file");
		if (sel==i) {kcola=0; continue;} // Same file, stop autoplay
		
		flen=FATvar.filelen>>10;	// in KBytes
		clearscr();
		// Read 1st KByte 
		n=rdfile((uint8_t *)&abuf[0]);   if (n<512) continue;
		n=rdfile((uint8_t *)&abuf[256]); if (n<512) continue;
		ps=(uint16_t *)abuf; 
		stereo=ps[22/2]-1;				// Number of channels minus one
		i=ps[24/2] | (ps[26/2]<<16);	// sample rate
		_printf("Playing \"%s\"... [q] stops [s] skips [p] pauses [esc] exits\n\n",p);
		_printf("(%s, %d S/s)\n\n( 0%%)\b\b",(stereo)?"stereo":"mono",i);
		// check if sample repetition is needed
		repe=1;
		if (i<16000) {repe=4; i<<=2;}
		 else if (i<26000) {repe=2; i<<=1;}
		// set closest sample rate
		if (i>46000) CONTROL=CONTROL|(1<<7);
		else {
			CONTROL&=~(3<<6);
			if (i>38000) CONTROL|=1<<6;
		}
		ardix=64;	// skip WAV header
		k=1;		// Kbytes leídos
		kcola=0x0a425B1B;	// <esc>, "[", "B", <nl>  (down_arrow, enter)
		while(1){
			while (ardix<256) asm volatile("WFI");
			n=rdfile((uint8_t *)&abuf[0]);   if (n<512) break;
			while (ardix>=256) asm volatile("WFI");
			n=rdfile((uint8_t *)&abuf[256]); if (n<512) break;
			if ((UARTSTA & RXVAL)) {
				i=UARTDAT;
				if (i==27) goto init;
				if (i=='q') {kcola=0; break;}
				if (i=='s') break;
				if (i=='p') {
					i=ardix; ardix=-1; // mute
					_puts("%) <paused>");
					_getch();
					_puts("\n(  %)\b\b");
					ardix=i;	// resume
				}
			}
			k++; 
			if ((k&0x3f)==0x3f) _printf("\b\b%2d",(k*100)/flen);
		}
		while (ardix<256) asm volatile("WFI");
		ardix=-1;
		GPOUT=0;
	}
	goto init;
	
adcplay:
	CONTROL=CSSD | CSPS | MODE3;
	FGCOLOR=0x02C;
	_puts("\n\nOsciloscope / Spectrum (press <esc> to quit)");
	while(1) {
		if(UARTSTA & RXVAL) {
			i=UARTDAT;
			switch(i) {
			case 'f':  ff^=1; cls(); break;
			case 'g': if (gain<5) gain++; break;
			case 'G': if (gain>0) gain--; break;
			case 'O': if (offset<2047-32) offset+=32>>gain; break;
			case 'o': if (offset>-(2047-32)) offset-=32>>gain; break;
			case 's': CONTROL+=1<<6; break;
			case 27 : goto init;
			}
		}
		if(ff) {
#ifdef FFT
			for (i=0;i<NSAMPLES;i++) { far[i]=(get_ADC()-2048)<<4; fai[i]=0;}
			window(far, NSAMPLES);
			fix_fft(far,fai, L2NS, 0);
			for (i=0;i<NSAMPLES/2;i++) far[i]=99+db_from_ampl(far[i], fai[i]);
			for (i=0;i<NSAMPLES/2-1;i++) {
				v1=100-far[i  ];
				v2=100-far[i+1];
				if (v1>v2) { j=v1; v1=v2; v2=j;}
				clearvline(i,   0,v1);
				setvline  (i,  v1,v2);
				clearvline(i,v2+1,100);
			}
#endif
		}else{
			for(i=0;i<320;i++) if (get_ADC_proc()<2048) break;
			for(i=0;i<320;i++) if (get_ADC_proc()>2047) break;
			for (i=0;i<321;i++) far[i]=get_ADC_proc();
			//for (i=0;i<320;i++) _printf("%d\n",far[i]);
			//cls();
			//for (i=0;i<320;i++) putpixel(i,240-((far[i]*15)>>8),1);
			for (i=0;i<320;i++) {
				v1=239-((far[i  ]*15)>>8);
				v2=239-((far[i+1]*15)>>8);
				if (v1>v2) { j=v1; v1=v2; v2=j;}
				clearvline(i,   0,v1);
				setvline  (i,  v1,v2);
				clearvline(i,v2+1,239);
			}
		}
		
	}

psramtst:
	CONTROL=CSSD |CSPS |SPIFAST | MODE7;	// Set PSRAM in QUAD mode	

	p=(uint8_t *)fbuf;
	_memset32(fbuf,0x20202020,40*30/4);
	_memcpy(&p[15*40+20-5],"PSRAM test",10);

	_puts("\nInit SD card to avoid contentions... ");
	i=SD_init(); // put SD card in SPI mode
	_puts( i ? "no card found" : "OK");

	_puts("\n\nPSRAM size = ");
	_memset32((uint32_t *)0x10000000,0,(16<<20)/4);
	pi=(uint32_t *)0x10000000;
	*pi=0xBEBACAFE;
	
	for (i=1024;i<=(16<<20);i<<=1) {
		if (pi[i>>2]==0xBEBACAFE) {_printf("%d KBytes\n",i>>10); break;}
	}
	n=i;
	_puts("\nTesting RAM\n\n1 - Fill with random data... ");
	j=0xBEBACAFE;
	for (i=0;i<n/4; i++) {
		pi[i]=j;
		j<<=1; j^=((j>>14)^(j>>13))&1;
	}
	_puts("done\n\n2 - Reading\n");
	j=0xBEBACAFE;
	for (i=v2=0;i<n/4; i+=(64<<10)/4) {
		for(k=0, v1='.'; k<(64<<10)/4; k++) {
			if (pi[i+k]!=j) v1='E';
			j<<=1; j^=((j>>14)^(j>>13))&1;
		}
		_putch(v1);
		if (v1=='E') v2=1;
		if (((i>>14)&15)==15) _printf(" (%2d MB)\n",1+(i>>18));
	}
	_puts(v2 ? "\nError\n" : "\nOK\n");
	_puts("\n(press a key)\n");
	_getch();
	goto init;
}
