//-------------------------------------------------------------------

//-------------------------------------------------------------------
`include "system.v"

module tb();

//-- Registros con señales de entrada
reg clk;
reg resetb;
reg rxd;
reg int;
wire txd;
wire sck, miso,mosi,ssb;
//-- Instanciamos 
wire [15:0]xa;
wire [15:0]xd;
wire xoe,xwe,xbhe,xble;

wire sck2,cspsram;
wire [3:0]qio;

SYSTEM sys1(	.clkin(clk),		// Main clock input 25MHz
	.resetin(~resetb),
	.rxd(rxd),
	.sck(sck), .miso(miso), .mosi(mosi), .csflash(ssb),
	.qio(qio), .sck2(sck2), .cspsram(cspsram)
);

FLASHSPI flash1( .sck(sck), .miso(miso), .mosi(mosi), .ssb(ssb) );

PSRAM psram1 (.sck(sck2), .ssb(cspsram), .qio(qio) );

// Reloj periódico
always #5 clk=~clk;

// INT 1.36 kHz
always begin
	#120000 int=0;
	#1800   int=1;
	#8750   int=0;
	#1800   int=1;
	#8750   int=0;
	#1800   int=1;
	#8750   int=0;
	#1800   int=1;
end

// INT 17kHz
//always #7353 int=~int;
//-- Proceso al inicio
initial begin
	//-- Fichero donde almacenar los resultados
	$dumpfile("tb.vcd");
	$dumpvars(0, tb);

	resetb = 1; clk=0; int=1; rxd=1;
	#33     resetb=0;

	#77		resetb=1;
	#25000  rxd=0;
	#160   	rxd=1;	// D0
	#160   	rxd=1;
	#160   	rxd=1;
	#160   	rxd=0;
	#160   	rxd=0;
	#160   	rxd=1;
	#160	rxd=1;
	#160   	rxd=0;	// D7
	#160   	rxd=1;
	
	//# 319 $display("FIN de la simulacion");
	# 500000 $finish;
	//# 1000 $finish;
end



endmodule


/////////////////////////////////////////////////////////////////////////////////////////////////////////

module FLASHSPI(
	input sck,
	input mosi,
	output miso,
	input ssb
);

reg [10:0]cnt=0;
always @(posedge sck or posedge ssb) if (ssb) cnt<=0; else cnt<=cnt+1;

reg [23:0]sh;
always @(posedge sck) sh<={sh[22:0],mosi};
reg [7:0]cmd;
reg[23:0]addr;
always @(posedge sck or posedge ssb) if (ssb) cmd<=0; else if (cnt==8) cmd<=sh[7:0];

always @(negedge sck or posedge ssb)
  if (ssb) addr<=0; else 
	if ((cmd==3)&(cnt==32)) addr<=sh; else
	if ((cnt>31) & (bit==0) & (cmd==3)) begin
		addr<=addr+1;
	end
reg [2:0]bit;
always @(negedge sck) bit<=~cnt[2:0];
wire [7:0]do=mem[addr];
assign miso=do[bit];

reg [7:0]mem[0:(1<<20)];
//integer i;
//initial begin
//	for (i=0;i<(1<<20); i=i+1) mem[i]=i;
//end
initial begin
  $readmemh("FlashROM.list", mem);
end

endmodule

/////////////////////////////////////////////////////////////////////////////////////////////////////////

module PSRAM(
	input sck,
	input ssb,
	inout [3:0]qio
);

parameter SIZE=8<<20;
localparam AW=$clog2(SIZE);
localparam NMEM=SIZE*2;

reg [3:0]mem[0:NMEM-1];

reg [4:0]cycnt=15;
reg [3:0]qdi;
reg [3:0]qdo;
reg [31:0]sh;
reg [24:0]a;
reg [7:0]cmd;
always @(posedge sck) qdi<=qio;

always @(negedge sck or posedge ssb) 
	if (ssb) cycnt<=0; else cycnt<=cycnt+1;
always @(negedge sck) begin
	sh<={sh[27:0],qdi};
	if (cycnt==7) begin
		cmd<=sh[27:20];
		a<={sh[19:0],qdi,1'b0};
	end
	else
		if ((cmd==8'h38)&(cycnt>7)) begin
			mem[a[AW:0]]<=qdi;
			a<=a+1;
		end 
		else 
		  if ((cmd==8'hEB)&(cycnt>12)) begin
		  	qdo<=mem[a[AW:0]];	
		  	a<=a+1;  	
		end
end

assign (weak1, weak0) qio = qdo;
	


endmodule

