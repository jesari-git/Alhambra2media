//--------------------------------------------------------------------
// RISC-V things 
// by Jesús Arias (2025)
//--------------------------------------------------------------------
/*
	Description:
	A LaRVA2 RISC-V system with 15KB of internal memory, video controller,
	and other peripherals.
	
	Memory map:
	
	0x00000000 to 0x00003BFF	Internal RAM, 15KB 
	0x00003C00 to 0x00003FFF	Zero, 1KB
	0x00004000 to 0x1FFFFFFF	the same internal RAM repeated each 16KB
	0x20000000 to 0x20FFFFFF	SPI Flash (16 MB max) Cached    
	0x21000000 to 0x3FFFFFFF    the same SPI Flash repeated each 16MB
	0x40000000 to 0xDFFFFFFF    Zero, 2.5 GB
	0xE0000000 to 0xE00000FF    IO registers
	0xE0000100 to 0xFFFFFFFF    the same IO registers repeated each 256B

	IO register map:
	
      address  |      WRITE        |      READ
    -----------|-------------------|---------------------------
    0xE0000000 | UART TX data      | UART RX data
    0xE0000004 |                   | UART flags
	0xE0000020 | Output Port       | Input Port, Output Port
	0xE0000040 | CONTROL, Clear fl.| STATUS, Control
    0xE0000060 | TMATCH Time match | TCNT Cycle counter
    0xE0000080 | COLORS            | COLORS
    0xE0000084 | VBASE             |
    0xE00000A0 | DAC               | ADC
    0xE00000B0 | SPI2              | SPI2
	0xE00000C0 | INTEN             | INTEN
	0xE00000C8 | BRK1              | BRK1
	0xE00000CC | BRK2              | BRK2
	0xE00000En | Interrupt Vectors | 

    UART FLAGS:   bit 4 bit 3 bit 2 bit 1 bit 0
                  CTRLC  OVE   FE   THRE   DV
                  
        RXVAL: RX Data Valid (Cleared reading data register)
        TXRDY: TX Ready (ready to write to data register if 1)
        FE:    Frame Error (Stop bit received as 0 if FE=1)
        OVE:   Overrun Error (Character received when RXVAL was still 1)
        CTRLC: Control-C (ASCII 3) received

	CONTROL / STATUS:   bit 15 bit 14 bit 13 bit 12 bit 11 bit 10 bit 9 bit 8 
                       SPIBUSY BRK2F  BRK1F  SCRDTY ADCIRQ TIMIRQ  VDE   HDE     
                       
                        bit 7:6 bit 5 bit 4 bit 3 bit 2 bit 1 bit 0
                         SRATE  CS_PS CS_SD  FAST TEXT   H2X   V2X
                       
        V2X      (RW): Video mode: Duplicate lines if 1
        H2X      (RW): Video mode: Duplicate pixels if 1
        TEXT     (RW): Video mode: Text mode if 1, graphics if 0
        FAST     (RW): Second SPI clock. 1: clk  0: clk/256
        CS_SD    (RW): Chip select for SD card (active low)
        CS_PS    (RW): Chip select for PSRAM (active low)
        SRATE    (RW): Sample rate for ADC & DAC
                       00: 31406 Hz (Same as HSYN)
                       01: 43620 Hz (44.1K - 1.1% error)
                       1x: 49072 Hz (48K + 2.2% error)
        HDE      (RC): Horizontal Display Enable (0 on retraces).
                       Clear horintal retrace IRQ if written with 1 
        VDE      (RC): Vertical Display Enable (0 on retaces).
                       Clear vertical retrace IRQ if written with 1 
        TIMIRQ   (RO): Timer matching interrupt flag. Cleared on writes to TMATCH
        ADCIRQ   (RO): Cleared on ADC read.
        SCRDTY   (RC): Screen Dirty. Set on UART writes, clear if written with 1
        BRK1F    (RC): Breakpoint 1 flag. Clear if written with 1
        BRK2F    (RC): Breakpoint 2 flag. Clear if written with 1
        SPIBUSY  (RO): Second SPI busy if one.

	TCNT, TMATCH: Autoincrement timer on reads, Matching value on writes.

    VBASE, COLORS:  bits 27:16 -- bits  11:0
                     ForeG BRG    BackG BRG
         Colors: BBBBGGGGRRRR, 4 bits for each component

    VBASE: bits 15:2 
         Video Base must be multiple of 4 

    ADC: (RO) bits 11:0  Analog level. Updated when ADCIRQ is set.

    DAC: (WO) bits 11:0, Analog level. Sampled when ADCIRQ is set. 
    
    SPI2: (R/W): 8-bit data to transmit on writes, received data on reads  
    
    INTEN:  bit 7   bit 6   bit 5  bit 4  bit 3  bit 2  bit 1  bit 0
           SSTEPIE CTRLCIE  ADCIE  TIMIE  UTXIE  URXIE  VDEIE  HDEIE
           
        HDEIE: Enable Horizontal retrace IRQ (end of visible pixels). 
        VDEIE: Enable Vertical retrace IRQ, (end of visible lines). 
        URXIE: Enable IRQ on UART data received (RXVAL set)
        UTXIE: Enable IRQ on UART ready to transmit (TXRDY set)
        TIMIE: Enable IRQ when timer equals the matching register (TCNT==TMATCH)
        ADCIE: Enable ADC IRQ (new sample available)
        CTRLCIE: Enable control-c IRQ (Break character)
        SSTEPIE: Enable Single-Step IRQ (after each instruction executed in user mode)
    
    BRKx: bits 32:2  bit 1  bit0
           BRKADDR    C/D    EN

		BRKADDR: Address where to stop execution (bits 1:0 not included)
		C/D:     0: Stop on Code Fetches, 1: Stop on Load/Store Data
		E:       Breakpoint enabled if 1
        
    Interrupt vectors from highest priority to lowest:
    
      Vector #0 (at 0xE00000E0): ECALL, EBREAK, control-C, Single-step interrupt, and BRKs.
      Vector #1 (at 0xE00000E4): Horizontal retrace
      Vector #3 (at 0xE00000EC): UART RX (data avaliable)
      Vector #6 (at 0xE00000F8): ADC (new sample)
      Vector #2 (at 0xE00000E8): Vertical retrace
      Vector #4 (at 0xE00000F0): UART TX (ready to transmit)
      Vector #5 (at 0xE00000F4): Timer matching TMATCH
*/

`define ENABLE_MULDIV
//`define RV32I				// 32 registers if defined (RV32E otherwise)
`define DITHER				// add random noise to DAC's LSB

`include "laRVa2_2.v"

`include "flashcache.v"
`include "uart_simple.v"
`include "video.v"
`include "sd_adc_2nd.v"
`include "sd_dac.v"
`include "spi_simple.v"
`include "qspiram.v"

module SYSTEM (
	input clkin,		// Main clock input 50MHz
	input resetin,		// Global reset (active high)

	input	rxd,		// UART
	output 	txd,

	output [1:0]red,	// RGB222 video output (for AP-VGA)
	output [1:0]green,
	output [1:0]blue,
	output hsyn,		// VGA horiz. sync.
	output vsyn,		// VGA vert. sync.
	
	output  [7:0]gpout,	// LEDs
	input   [1:0]gpin,	// Buttons
	
	output dac1b,		// Audio output (PWM/SD)
	
	input  sdin,		// Sigma-delta input
	output sdfb,		// Sigma-delta feedback
	
	output sck,			// SPI bus (for Flash memory)
	output mosi,
	output csflash,
	input  miso,

	output sck2,		// 2nd SPI bus (for SD card & PSRAM)
	output cssd,
	output cspsram,
	//output mosi2,
	//input  miso2
	inout [3:0]qio,	// Quad SPI data
	output debug
);

`ifdef RV32I
	parameter NREG=32;			//RV32I
`else
	parameter NREG=16;			//RV32E
`endif

parameter FCLK=50250000;	// double clock rate (for flash SPI & audio clock divider)
parameter BAUD=115200;

localparam CCLK=FCLK/2;		// Main frequency for CPU, VGA Video, and most of peripherals

//////////////////////////////////////////////////////
// clock divider & reset

reg clk=0;	// 25MHz main clock
always @(posedge clkin) clk<=~clk;

reg reset=1;	// Sampled reset (just in case...)
always @(posedge clk) reset<=resetin;

///////////////////////////////////////////////////////////////////////////////
//////////////////////////             CPU             ////////////////////////
///////////////////////////////////////////////////////////////////////////////

wire [31:0]	ca;		// CPU Address (4-byte aligned: ca[1:0] unused by the core)
wire [31:0]	cdo;	// CPU Data Output
wire [3:0]	mwe;	// Memory Write Enable (4 signals, one per byte lane)
wire rd = (mwe==4'b0000);	// Memory read
wire vma;			// Valid Memory Address
// Wait on Video Reads, cache misses, or slow PSRAM active
wire wai= (vrd & iramcs) | flashwait | pswait;	
wire trap;			// ECALL/EBREAK executed
wire irq;			// Interrupt request
wire [31:2]ivector;	// Interrupt Vector address (4-byte aligned)
wire usermode;		// 1: mode normal (user), 0: mode IRQ (machine)
wire fetch;			// 1: code read, 0: data read / write
wire brk;			// hardware breakpoint input

assign ca[1:0]=2'b00;	// for easy debug
laRVa #(.NREG(NREG),.RESET_PC(32'h20030000)) cpu (
	.clk     (clk ),
	.reset   (reset),
	.wai	 (wai),
	.vma	 (vma),
	.addr    (ca[31:2] ),
	.wdata   (cdo  ),
	.wstrb   (mwe  ),
	.rdata   (cdi  ),
	.irq     (irq  ),
	.trap    (trap ),
	.ivector (ivector),
	.usermode (usermode),
	.fetch   (fetch),
	.brk     (brk)
);
 
///////////////////////////////////////////////////////
///// Memory mapping
///////////////////////////////////////////////////////

// Internal RAM selected in lower 256MB (0-0x0FFFFFFF)
wire iramcs = vma & (ca[31:28]==4'b0000);
// PSRAM (0x10000000-0x1FFFFFFF)
wire psramcs= vma & (ca[31:28]==4'b0001);

// SPI Flash with cache (0x20000000-0x3FFFFFFF)
wire flashcs = vma & rd & (ca[31:29]==3'b001); 

// IO selected in last 512MB (0xE0000000-0xFFFFFFFF)
// (~wai for single read / write strobe pulses )
wire iocs   = (~wai) & vma & (ca[31:29]==3'b111);

// CPU Input bus mux
wire [31:0]cdi = 
	(iramcs  ? mdo     : 0) |
	(psramcs ? psdo    : 0) |
	(flashcs ? flashdo : 0) |
	(iocs    ? iodo    : 0);

///////////////////////////////////////////////////////
///////////        internal memory       //////////////
/////////// Shared with Video controller //////////////
///////////////////////////////////////////////////////

// address: CPU or Video
wire [11:0]ma = vrd ? va + vbas : ca[13:2];

// 15KB in 4 different RAM sizes (reserve 2 BRAMs for flash cache)
wire cs8= (iramcs | vrd) & (~ma[11]);
wire cs4= (iramcs | vrd) & (ma[11:10]==2'b10);
wire cs2= (iramcs | vrd) & (ma[11:9]== 3'b110);
wire cs1= (iramcs | vrd) & (ma[11:8]== 4'b1110);
wire [3:0]mmwe = vrd ? 4'b0000 : mwe; // force read if video access
wire [31:0]md8o; // outputs
wire [31:0]md4o;
wire [31:0]md2o;
wire [31:0]md1o;

ram32 #(.AW(13)) 
	mem8 ( .clk(clk), .cs(cs8), .mwe(mmwe), .a(ma[10:0]), .d(cdo), .q(md8o) );
ram32 #(.AW(12))
	mem4 ( .clk(clk), .cs(cs4), .mwe(mmwe), .a(ma[9:0]), .d(cdo), .q(md4o) );
ram32 #(.AW(11))
	mem2 ( .clk(clk), .cs(cs2), .mwe(mmwe), .a(ma[8:0]), .d(cdo), .q(md2o) );
ram32 #(.AW(10))
	mem1 ( .clk(clk), .cs(cs1), .mwe(mmwe), .a(ma[7:0]), .d(cdo), .q(md1o) );

wire [31:0]mdo = md8o | md4o | md2o | md1o ;	// Output data

///////////////////////////////////////////////////////
////////////////////  Cached Flash   //////////////////
///////////////////////////////////////////////////////
wire [31:0]flashdo;	// data output
wire flashwait;		// wait states on cache misses

flashcache flash0 (
	.clk(clkin), 	// runs with a double rate clock (50MHz)
	.flush(reset), .addr(ca[23:2]), .do(flashdo),
	.strobe (flashcs & rd & (~clk)), 
	.sck(sck), .sdo(mosi), .sdi(miso), .cs(csflash),
	.wai(flashwait)
);	

///////////////////////////////////////////////////////
////////////////////  PSRAM (QPSI)   //////////////////
///////////////////////////////////////////////////////
wire pswait;
wire quad=ctrl[4] & ctrl[5];  // Quad mode if no SPI device selected
wire qcs=psramcs & quad;
wire [31:0]psdo;
wire [3:0]qdo;
wire qss,qoe;
assign debug=qoe;

assign qio[3:1]= quad&qoe ? qdo[3:1] : 3'bzzz;
assign qio[0]= quad&(~qoe)? 1'bz : (quad ? qdo[0] : mosi2);

assign sck2=qsck | scks;

delaych #(.NCELLS(1)) del0(.in(qio[1]), .out(miso2));

assign cspsram= qss & ctrl[5];

qspiram QRAM0(.clk(clk), .reset(reset), .cs(qcs), .mwe(mwe),
	.a(ca[23:2]), .di(cdo), .do(psdo), .busy(pswait),
	.sck(qsck), .ss(qss), .qdo(qdo), .qdi(qio), .oe(qoe) );

/////////////////////////////////////////////////////////////////
//////////////////         Peripherals        ///////////////////
/////////////////////////////////////////////////////////////////
wire uartcs = iocs&(ca[7:5]==3'b000);	// UART	   at offset 0x00
wire gpocs  = iocs&(ca[7:5]==3'b001);	// GPOUT   at offset 0x20
wire ctlcs  = iocs&(ca[7:5]==3'b010);	// CTRL    at offset 0x40
wire timcs  = iocs&(ca[7:5]==3'b011);	// TIMER   at offset 0x60
wire vbpcs  = iocs&(ca[7:5]==3'b100);	// VBASPAL at offset 0x80
wire adcs   = iocs&(ca[7:4]==4'b1010);	// ADC/DAC at offset 0xA0
wire spics  = iocs&(ca[7:4]==4'b1011);	// SPI     at offset 0xB0
wire irqcs  = iocs&(ca[7:5]==3'b110);	// IRQEN   at offset 0xC0
wire veccs  = iocs&(ca[7:5]==3'b111);	// IRQVEC  at offset 0xE0

// Peripheral output bus mux

reg [31:0]iodo;		// not a register
always @*
	casex(ca[7:2])
		6'b000xx0: iodo = {24'h0,uart_do};
		6'b000xx1: iodo = {27'h0,ctrlc,urxoverr,urxframeer,utxrdy,urxvalid};
		6'b001xxx: iodo = {22'h0,gpin,gpout};
		6'b010xxx: iodo = {16'h0,spibusy,brk2f,brk1f,scrdty,adcirq,timirq,vde,hde,ctrl};
		6'b011xxx: iodo = tcount;
		6'b100xx0: iodo = {10'h0,fgcolor,10'h0,bgcolor};
		6'b100xx1: iodo = {16'h0000,vbas,2'b00};
		6'b1010xx: iodo = {20'h0,adcout};
		6'b1011xx: iodo = {24'h0,spiq};
		6'b110x0x: iodo = {24'h0,irqen};
		6'b110x10: iodo = brk1;
		6'b110x11: iodo = brk2;
		default:   iodo = 0;
	endcase

//////////////////////////////////////////////////
// UART

wire utxrdy,rxvalid,urxframeer,urxoverr; // Flags
wire [7:0] uart_do;	// RX output data

// Strobes
wire uwrtx   = uartcs & (~ca[2]) & mwe[0];	// write TX
wire urd     = uartcs & (~ca[2]) & rd; 		// read RX: clear DV and OVE flags

`ifndef SIMULATION
	localparam DIVU=(CCLK+BAUD/2)/BAUD;	// real baud rate
`else
	localparam DIVU=8;					// fast baud rate
`endif
UART_simple_core #(.DIVIDER(DIVU)) uart0 ( 
	.clk(clk), .d(cdo[7:0]), .wr(uwrtx),. rd(urd), .q(uart_do),
	.rxvalid(urxvalid), .txrdy(utxrdy),
	.rxoverr(urxoverr), .rxframeer(urxframeer),
	.nstop(1'b0),
	.txd(txd), .rxd(rxd)
);

wire ctrlc = urxvalid & (uart_do==8'd3);	// CTRL-C received
reg scrdty=0;	// screen dirty
always @(posedge clk) scrdty<=uwrtx ? 1 : (ctlcs & mwe[1] & cdo[12] ? 0 : scrdty);

//////////////////////// GPOUT /////////////////////////
reg [7:0]gpout;
always @(posedge clk) if (gpocs&mwe[0]) gpout<=cdo[7:0];

/////////////////// Timer counter //////////////////////
reg [31:0]tcount=0;
always @(posedge clk) tcount<=tcount+1;
reg [31:0]tmatch=0;
wire wrtmatch = timcs&(mwe[3:0]==4'b1111);
always @(posedge clk) if (wrtmatch) tmatch<=cdo;
reg timirq=0;
always @(posedge clk) timirq <= (tcount==tmatch) ? 1 : (wrtmatch ? 0 : timirq);

////////// Control (video mode, ADC channel) ///////////
reg [7:0]ctrl=0;
always @(posedge clk) if (ctlcs&mwe[0]) ctrl<=cdo[7:0];

//////////////// Video base & palette //////////////////
reg [13:0]vbas=0;
reg [5:0]fgcolor=6'b11_11_11;
reg [5:0]bgcolor=6'b00_00_01;
always @(posedge clk) if (vbpcs) begin
	if (mwe[0]&(~ca[2])) bgcolor[5:0] <= cdo[5:0];
	if (mwe[2]&(~ca[2])) fgcolor[5:0] <= cdo[21:16];
	
	if (mwe[0]&ca[2]) vbas[5:0] <= cdo[7:2];
	if (mwe[1]&ca[2]) vbas[13:6]<= cdo[15:8];
end

////////////////////////////////////////////////////////
//		Video Controller

wire [11:0]va;	// video address
wire video1bpp,hde,vde,vrd;

video VGA(	.clk(clk), .d(mdo), .va(va), .vrd(vrd),
			.hsyn(hsyn), .vsyn(vsyn), .video(video1bpp), .hde(hde), .vde(vde),
			.text(ctrl[2]), .h2x(ctrl[1]), .v2x(ctrl[0])
		);
assign {red,green,blue} = (hde & vde) ? (video1bpp ? fgcolor : bgcolor) : 0;

// video interrupts
reg ohde; reg ovde; 				// for falling edge detect
reg horzirq; reg vertirq;
wire clrh=ctlcs & mwe[1] & cdo[8];	// Clear horizontal IRQ flag
wire clrv=ctlcs & mwe[1] & cdo[9];	// Clear vertical IRQ flag

always @(posedge clk) begin
	ohde<=hde;
	ovde<=vde;
	horzirq<= clrh ? 0 : ( ohde & (~hde) ? 1 : horzirq);
	vertirq<= clrv ? 0 : ( ovde & (~vde) ? 1 : vertirq);
end

//////////////////////////////////////////////////////////////////
// 	SIGMA-DELTA ADC

// ADC & DAC clock divider controlled by ctrl[7:6] 
// 00 -> * 2/25 -> 31.4 kHz (HVIDEO)
// 01 -> * 2/18 -> 43.6 kHz (44.1 - 1.1%)
// 1x -> * 2/16 -> 49.1 kHz (48.0 + 2.2%)
reg [4:0]adckdiv=0;
wire addivmax = ctrl[7] ? &adckdiv[3:0] : adckdiv[4]&(ctrl[6] ? adckdiv[0]: adckdiv[3]);
always @(posedge clkin) adckdiv <= addivmax ? 0 :  adckdiv + 1;
wire sdclk = ctrl[7] ? adckdiv[3]: adckdiv[4];

// Decimation counter (1/64)
reg [5:0]sddeci=0;		// Decimator counter
wire nsamp = &sddeci;	// new sample after maximal count
always @(posedge sdclk) sddeci<=sddeci+1;

// SD instance
wire [11:0]adcout;
sd_ADC_2nd ADC0( .clk(sdclk), .sdin(sdin), .fb(sdfb), .newsample(nsamp), .out(adcout) );

// IRQ
reg adcirq=0;
reg onsamp;
always @(posedge clk) onsamp<=nsamp;
always @(posedge clk) adcirq<= ((~onsamp)&nsamp) ? 1 : ((adcs & rd) ? 0 : adcirq);

//////////////////////////////////////////////////////////////////
// 	SIGMA-DELTA DAC

reg [11:0]dacval=0;
always @(posedge clk) if (adcs & mwe[0] & mwe[1]) dacval<=cdo[11:0];
reg [11:0]dachold=0;
always @(posedge sdclk) if (nsamp) dachold<=dacval;

sd_DAC DAC0( .clk(sdclk), .in({~dachold[11],dachold[10:1],dachold[0]^prbs}), .out(dac1b) );

`ifdef DITHER 
	// dither reg
	//reg [23:0]lfsr;
	reg [14:0]lfsr;
	always @(posedge sdclk or posedge reset)
	  //if (reset) lfsr<=24'hFFFFFF; else lfsr<={lfsr[22:0], lfsr[23]^lfsr[22]^lfsr[20]^lfsr[19]};
	  if (reset) lfsr<=15'h7FFF; else lfsr<={lfsr[13:0], lfsr[14]^lfsr[13]};
	wire prbs=lfsr[0];
`else
	wire prbs=1'b0;
`endif

//////////////////////////////////////////////////////////////////
//	SPI controller for SD card / PSRAM
wire [7:0]spiq;
wire spibusy;
wire scks,mosi2,miso2;

spi_simple SPISD( .clk(clk), .we(spics & mwe[0]), .d(cdo[7:0]),
				.q(spiq), .fast(ctrl[3]), .busy(spibusy),
				.sck(scks), .mosi(mosi2), .miso(miso2)
);

assign cssd = ctrl[4];
//assign cspsram = ctrl[5];

//////////////////////////////////////////////////////////////////
// Hardware breakpoints

wire brk1wr = irqcs & (mwe==4'b1111) & (ca[3:2]==2'b10);
wire brk2wr = irqcs & (mwe==4'b1111) & (ca[3:2]==2'b11);
reg [31:0]brk1;
reg [31:0]brk2;
always @(posedge clk or posedge reset) 
	if (reset) brk1<=0; else if (brk1wr) brk1 <= cdo;

always @(posedge clk or posedge reset) 
	if (reset) brk2<=0; else if (brk2wr) brk2 <= cdo;

// matching
wire matbrk1 = (ca[31:2]==brk1[31:2]) & (fetch ^ brk1[1]) & brk1[0];
wire matbrk2 = (ca[31:2]==brk2[31:2]) & (fetch ^ brk2[1]) & brk2[0];
assign brk= vma &(matbrk1 | matbrk2);
// flags
reg brk1f=0;
reg brk2f=0;
always @(posedge clk or posedge reset) 
	if (reset) begin brk1f<=0; brk2f<=0; end
	else begin
		brk1f<= matbrk1 ? 1 : (ctlcs & mwe[1] & cdo[13] ? 0 : brk1f);
		brk2f<= matbrk2 ? 1 : (ctlcs & mwe[1] & cdo[14] ? 0 : brk2f);
	end

//////////////////////////////////////////
//////////////////////////////////////////
//    Interrupt control
//////////////////////////////////////////
//////////////////////////////////////////

// IRQ enable reg
reg [7:0]irqen=0;
always @(posedge clk or posedge reset) begin
	if (reset) irqen<=0; else
	if (irqcs & (ca[3:2]==2'b00) & mwe[0]) irqen<=cdo[7:0];
end

// IRQ vectors
reg [31:2]irqvect[0:7];
always @(posedge clk) if (veccs & (mwe==4'b1111)) irqvect[ca[4:2]]<=cdo[31:2];

// Enabled IRQs
wire [7:0]irqpen={	
					irqen[7] & usermode,	// Single-step IRQ
					irqen[6] & ctrlc,
					irqen[5] & adcirq,
					irqen[4] & timirq,
					irqen[3] & utxrdy,
					irqen[2] & urxvalid,
					irqen[1] & vertirq,
					irqen[0] & horzirq
				 };	// pending IRQs

// Priority encoder
wire [2:0]vecn = 								// -- highest priority --
	trap | irqpen[6] |irqpen[7] ? 3'b000 : (	// Vector #0: trap, ctrl-c, single-step
					 irqpen[0]  ? 3'b001 : (	// Vector #1: Video HSYN
					 irqpen[2]  ? 3'b011 : (	// Vector #3: UART RX
					 irqpen[5]  ? 3'b110 : (	// Vector #6: ADC
					 irqpen[1]  ? 3'b010 : (	// Vector #2: Video VSYN
					 irqpen[3]  ? 3'b100 : (	// Vector #4: UART TX
					 irqpen[4]  ? 3'b101 : (	// Vector #5: Timer IRQ
					 		3'b111
					 )))))));                    // -- lowest priority --
assign ivector = irqvect[vecn];
assign irq = |{irqpen,trap};


endmodule	// System

//-------------------------------------------------------------------------------------------------------

//////////////////////////////////////////////////////////////////////////////
//----------------------------------------------------------------------------
//-- 32-bit RAM Memory with independent byte-write lanes
//----------------------------------------------------------------------------
//////////////////////////////////////////////////////////////////////////////

module ram32
 (	input	clk,
	input	cs,			// "chip"-select, active high
	input	[3:0]mwe,	// byte lane select for writes
	input	[AW-3:0]a,	// address
	output	[31:0]	q,	// read output
	input	[31:0] 	d	// write input
 );
parameter AW=14; 		// address Width (bytes)

reg [31:0] ram_array [0:(1<<(AW-2))-1];
reg [31:0] data_out;
        
assign q = cs ? data_out : 0;
        
always @(posedge clk) begin
	if (cs & mwe[0]) ram_array[a][ 7: 0] <= d[ 7: 0];
	if (cs & mwe[1]) ram_array[a][15: 8] <= d[15: 8];
	if (cs & mwe[2]) ram_array[a][23:16] <= d[23:16];
	if (cs & mwe[3]) ram_array[a][31:24] <= d[31:24];
end

always @(negedge clk) begin
	data_out <= ram_array[a];
end
// known initial values for simulations (Stupid Verilog!)
integer i;
initial begin
	for (i=0;i<(1<<(AW-2)); i=i+1) ram_array[i] = 32'h00000000;
end

endmodule

//////////////////////////////////////////////////////////////////////////////
// delay chain

module delaych (
	input in,
	output out 
);
	
parameter NCELLS=3;	

wire [NCELLS:0]tap;
assign tap[0]=in;
assign out=tap[NCELLS];
generate 
	genvar i;
	for (i=0; i<NCELLS; i=i+1) begin	
		SB_LUT4 #(.LUT_INIT(16'hAAAA)) bufb (.O(tap[i+1]),.I0(tap[i]),
				.I1(1'b0), .I2(1'b0), .I3(1'b0));	
	end
endgenerate
endmodule

