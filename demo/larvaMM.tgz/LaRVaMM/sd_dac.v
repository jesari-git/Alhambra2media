//----------------------------------------------------------------------------
//-- 2nd-order Sigma-Delta DAC
//   J. Arias (2023) Public domain source
//----------------------------------------------------------------------------

module sd_DAC(
	input clk,		// around 3MHz, (2.82MHz for 44100/2^n)
	input [NBIT-1:0]in,	// 12 bits, signed
	output out,		// output bitstream
	output sclk		// sampling clock (clk/OSR)
);

parameter NBIT=12;	// Input sample resolution

// The SD modulator input, x, come from input (with sign extension)
wire [NBIT+2:0]x={{3{in[NBIT-1]}},in};

///////////////////// SD MODULATOR (DAC) ///////////////////////////
// 3 more bits for variables in order to avoid overflows
wire [NBIT+2:0]err;		// Quantization error
reg  [NBIT+2:0]e1=0;	// error 1 cycle before
reg  [NBIT+2:0]e2=0;	// error 2 cycle before
wire [NBIT+2:0]y;		// filter output
wire outp;			// output bit
reg out=0;			// registerred output (to avoid glitches & variable delays)

assign y=x+{e1[NBIT+1:0],1'b0}+(~e2)+1'b1;	// y=x+2*e1-e2 
assign outp=y[NBIT+2];						// output = sign bit
localparam FULLSC=19'h3<<(NBIT-2);

assign err=y+(outp ? -FULLSC : FULLSC); // Quantization error
											// Full scale at +-150% to avoid excess noise
always @(posedge clk) begin		// Register update
	e1<=err;
	e2<=e1;
	out<=outp;
end

endmodule

