/*-------------------------------------------------------------------------
Digital filter for a 2nd-order Sigma-Delta modulator

J. Arias (2023) Public domain sources

This is a 3rd-order Comb filter with a 1/64 decimation factor
that is equivalent to a cascade of 3 moving averages of 64 samples each
followed by a sample output every 64
  input is 1-bit (unsigned)
  output is 12-bit (unsigned)
  Internal variables must have a minimum number of bits:
     Nbit = Nbit_input + Filter_Order * log2(decimation)
     Nbit = 1 + 3 * 6 = 19 bits

-------------------------------------------------------------------------*/
module sd_ADC_2nd(
	input clk,			// 64 x Fs clock (falling edge)
	input sdin,			// input from analog comparator
	output fb,			// Feedback to integrator
	input  newsample,	// New output sample next clock pulse
	output [11:0]out	// Output data
);

reg fb=0;
reg [18:0]inte1=0;		// Integrator registers
reg [18:0]inte2=0;
reg [18:0]inte3=0;
reg [18:0]diff1=0;		// differenciator registers
reg [18:0]diff2=0;
reg [18:0]diff3=0;
wire [18:0]add1 = (~fb) + inte1;	// Integrator adders
wire [18:0]add2 = add1 + inte2;
wire [18:0]add3 = add2 + inte3;

wire [18:0]sub1 = add3 - diff1;		// Differenciator subs
wire [18:0]sub2 = sub1 - diff2;
wire [18:0]sub3 = sub2 - diff3;

reg [11:0]out=0;		// Output register (12 bits, but only 10.4 effective bits)

always @(posedge clk) begin
	fb <= ~sdin;		// Negative feedback loop
	inte1 <= add1;		// Integrators
	inte2 <= add2;
	inte3 <= add3;
	if (newsample) begin	// every 64 cycles
		diff1 <= add3;	// Differenciators
		diff2 <= sub1;
		diff3 <= sub2;
		// Output with saturation
		out <= sub3[18] ? 12'hfff : sub3[17:6];
	end
end

endmodule

