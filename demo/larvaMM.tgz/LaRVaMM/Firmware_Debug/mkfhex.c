#include <stdlib.h>
#include <stdio.h>
#include <string.h>

unsigned char mem[1<<20];

main(int argc, char **argv)
{
	FILE *fp;
	int i;
	
	memset(mem,0xff,1<<20);
	
	fp=fopen(argv[1],"r");
	fread(&mem[0x30000],1,(1<<20)-0x30000,fp);
	fclose(fp);

	fp=fopen("../laRVa2_2.v","r");
	fread(&mem[0x40000],1,(1<<20)-0x40000,fp);
	fclose(fp);


	fp=fopen(argv[2],"w");
	for (i=0;i<(1<<20);i++) fprintf(fp,"%02x\n",mem[i]);
	fclose(fp);
}
