
#include <stdint.h>
#include "system.h"

void _putch(int c)
{
	while((UARTSTA & TXRDY)==0);
	//if (c == '\n') _putch('\r');
	UARTDAT = c;
}

void _puts(const char *p)
{
	while (*p)
		_putch(*(p++));
}

int _strlen(char *p) 
{
	int i=0;
	while (*p++) i++;
	return i;
}

uint8_t _getch()
{
	while((UARTSTA&1)==0);
	return UARTDAT;
}

#define putchar(d) _putch(d)
#include "printf.c"

int _getsn(char *pd, int max)
{
	int d;
	char *pb;
	pb=pd;
	
	while(1) {
		d=_getch();
		if (d=='\n' || d=='\r') {*pd=0; return (int)(pd-pb);}
		if (d=='\b' || d==127) {
			if (pd!=pb) {
				_puts("\b \b");
				pd--;
			}
			continue;
		}
		if ((int)(pd-pb)< (max-1)) {*pd++=d; _putch(d);}
	}
}

int rdhex(char *p)
{
	unsigned int d,a;
	d=0;
	while (1) {
		a=*p++;
		if (a>'Z') a-=32;	// uppercase
		if (a>='0' && a<='9') a-='0';
		else if (a>='A' && a<='F') a-='A'-10;
			else break;
		d<<=4; d+=a;
	}
	return d;
}

int rddec(char *p)
{
	unsigned int d,a;
	d=0;
	while (1) {
		a=*p++;
		if (a>='0' && a<='9') a-='0';
		else break;
		d*=10; d+=a;
	}
	return d;
}

void hexdump(char *p)
{
	int i,j;
	
	for (i=0;i<16;i++) {
		_printf("%08X  ",(uint32_t)p);
		for (j=0;j<16;j++) _printf("%02X ",p[j]);
		_putch(' ');
		for (j=0;j<16;j++) _putch((p[j]>=32 && p[j]<127)? p[j] : '.');
		_putch('\n');
		p=&p[j];
	}
}

void __attribute__((naked)) loader(){
asm volatile(
"	lui		a3,0xE0000	\n"
"	li		a1,0x4c		\n"
"1:	call	bgetch		\n"		// wait until 'L'
"	bne		a0,a1, 1b	\n"
"	sb		a0,0(a3)	\n"		// echo L
"	jal		tp,getw		\n"		// read base addr		
"	mv		t0,a0		\n"
"	jal		tp,getw		\n"		// read nbytes
"	add		t1,t0,a0	\n"		// last addr
"	jal		tp,getw		\n"		// read entry addr
"	mv		t2,a0		\n"
"	j		3f			\n"

"2:	call	bgetch		\n"
"	sb		a0,0(t0)	\n"
"	addi	t0,t0,1		\n"
"3:	bne		t0,t1,2b	\n"
"	la		sp,_stack	\n"		// SP below debugger vars	
"	li		a0,0x10		\n"
"	sb		a0,0x41(a3)	\n"		// clear dirty
"	li		a0,0xC0		\n"
"	sb		a0,0xC0(a3)	\n"		// enable IRQs
"	jr		t2			\n"		// Jump to program

"getw: 					\n"		// reads 32-bit into a0 (return address in tp)
"	call	bgetch		\n"		// (jal	 ra,bgetch)
"	mv		a1,a0		\n"
"	call	bgetch		\n"
"	slli 	a0,a0,8		\n"
"	or		a1,a1,a0	\n"
"	call	bgetch		\n"
"	slli 	a0,a0,16	\n"
"	or		a1,a1,a0	\n"
"	call	bgetch		\n"
"	slli 	a0,a0,24	\n"
"	or		a0,a0,a1	\n"
"	jalr	zero,tp		\n"		// return (tp: return address)

"bgetch: 				\n"		// reads byte into a0
"	lbu 	a0,4(a3)	\n"		// while (UARTSTAT & 1) ==0
"	andi	a0,a0,1		\n"
"	beq		a0,x0,bgetch\n"
"	lbu 	a0,0(a3)	\n"		// return UARTDAT
"	ret					\n"		// (jalr  zero,ra)
);
}

#include "dissaRVEM.c"

void help()
{
	_puts(
	"\nCommands:\n"
	" h:\tHelp\n"
	" c:\tContinue\n"
	" s:\texecute Single instruction\n"
	" n:\texecute until Next instruction\n"
	" r:\texecute until subroutine Return (any)\n"
	" R:\texecute until Return at higher stack level\n"
	" b:\tset Breakpoint\n"
	" B:\tset Data Breakpoint\n"
	" g:\tGoto (change PC)\n"
	" x:\tchange X register\n"
	" d:\tDissasemble\n"
	" m:\tMemory dump\n"
	" w:\tmemory Write, \"-\": addr--\n"
	" l:\tLoad code to debug\n"
	" a:\tAlternate register names\n"
	" ctrl-c\tPauses execution\n"
	);
}

#ifdef RV32E
  #define PCOFF (15)
  #define NREG	(16)
  #define NDIS	(14)
#else
  #define PCOFF (15+16)
  #define NREG  (32)
  #define NDIS  (10)
#endif

void __attribute__((naked)) debug_handler()
{
	asm volatile(
#ifdef RV32E
	"	addi	sp,sp,-64		\n"
	"	sw		x1,0(sp)		\n"
	"	addi	x1,sp,64		\n"
	"	sw		x1,4(sp)		\n"	// current SP
	"	sw		x3,8(sp)		\n"
	"	sw		x4,12(sp)		\n"
	"	sw		x5,16(sp)		\n"
	"	sw		x6,20(sp)		\n"
	"	sw		x7,24(sp)		\n"
	"	sw		x8,28(sp)		\n"
	"	sw		x9,32(sp)		\n"
	"	sw		x10,36(sp)		\n"
	"	sw		x11,40(sp)		\n"
	"	sw		x12,44(sp)		\n"
	"	sw		x13,48(sp)		\n"
	"	sw		x14,52(sp)		\n"
	"	sw		x15,56(sp)		\n"
	"	csrrw	x1,0x341,zero	\n"	// Interrupted PC
	"	sw		x1,60(sp)		\n"
	"	mv		a0,sp			\n"
	"	call	singlestep		\n"
	"	lw		x1,60(sp)		\n"
	"	csrrw	zero,0x341,x1	\n"	// allows PC changes
	"	lw		x1,0(sp)		\n"
	"	lw		x3,8(sp)		\n"
	"	lw		x4,12(sp)		\n"
	"	lw		x5,16(sp)		\n"
	"	lw		x6,20(sp)		\n"
	"	lw		x7,24(sp)		\n"
	"	lw		x8,28(sp)		\n"
	"	lw		x9,32(sp)		\n"
	"	lw		x10,36(sp)		\n"
	"	lw		x11,40(sp)		\n"
	"	lw		x12,44(sp)		\n"
	"	lw		x13,48(sp)		\n"
	"	lw		x14,52(sp)		\n"
	"	lw		x15,56(sp)		\n"
	"	lw		sp,4(sp)		\n" // Allows SP changes
	"	mret					\n"
#else
	"	addi	sp,sp,-128		\n"
	"	sw		x1,0(sp)		\n"
	"	addi	x1,sp,128		\n"
	"	sw		x1,4(sp)		\n"	// current SP
	"	sw		x3,8(sp)		\n"
	"	sw		x4,12(sp)		\n"
	"	sw		x5,16(sp)		\n"
	"	sw		x6,20(sp)		\n"
	"	sw		x7,24(sp)		\n"
	"	sw		x8,28(sp)		\n"
	"	sw		x9,32(sp)		\n"
	"	sw		x10,36(sp)		\n"
	"	sw		x11,40(sp)		\n"
	"	sw		x12,44(sp)		\n"
	"	sw		x13,48(sp)		\n"
	"	sw		x14,52(sp)		\n"
	"	sw		x15,56(sp)		\n"

	"	sw		x16,60(sp)		\n"
	"	sw		x17,64(sp)		\n"
	"	sw		x18,68(sp)		\n"
	"	sw		x19,72(sp)		\n"
	"	sw		x20,76(sp)		\n"
	"	sw		x21,80(sp)		\n"
	"	sw		x22,84(sp)		\n"
	"	sw		x23,88(sp)		\n"
	"	sw		x24,92(sp)		\n"
	"	sw		x25,96(sp)		\n"
	"	sw		x26,100(sp)		\n"
	"	sw		x27,104(sp)		\n"
	"	sw		x28,108(sp)		\n"
	"	sw		x29,112(sp)		\n"
	"	sw		x30,116(sp)		\n"
	"	sw		x31,120(sp)		\n"

	
	"	csrrw	x1,0x341,zero	\n"	// Interrupted PC
	"	sw		x1,124(sp)		\n"
	"	mv		a0,sp			\n"
	"	call	singlestep		\n"
	"	lw		x1,124(sp)		\n"
	"	csrrw	zero,0x341,x1	\n"	// allows PC changes
	"	lw		x1,0(sp)		\n"
	"	lw		x3,8(sp)		\n"
	"	lw		x4,12(sp)		\n"
	"	lw		x5,16(sp)		\n"
	"	lw		x6,20(sp)		\n"
	"	lw		x7,24(sp)		\n"
	"	lw		x8,28(sp)		\n"
	"	lw		x9,32(sp)		\n"
	"	lw		x10,36(sp)		\n"
	"	lw		x11,40(sp)		\n"
	"	lw		x12,44(sp)		\n"
	"	lw		x13,48(sp)		\n"
	"	lw		x14,52(sp)		\n"
	"	lw		x15,56(sp)		\n"
	
	"	lw		x16,60(sp)		\n"
	"	lw		x17,64(sp)		\n"
	"	lw		x18,68(sp)		\n"
	"	lw		x19,72(sp)		\n"
	"	lw		x20,76(sp)		\n"
	"	lw		x21,80(sp)		\n"
	"	lw		x22,84(sp)		\n"
	"	lw		x23,88(sp)		\n"
	"	lw		x24,92(sp)		\n"
	"	lw		x25,96(sp)		\n"
	"	lw		x26,100(sp)		\n"
	"	lw		x27,104(sp)		\n"
	"	lw		x28,108(sp)		\n"
	"	lw		x29,112(sp)		\n"
	"	lw		x30,116(sp)		\n"
	"	lw		x31,120(sp)		\n"
	
	"	lw		sp,4(sp)		\n" // Allows SP changes
	"	mret					\n"
#endif
	);
}



// Single-Step
static uint8_t notrace,stopjalr;
void singlestep(uint32_t *stack){
	int i,j,k,l;
	uint32_t *pc;
	uint8_t const * const *rn;
	char buf[12];
	static uint32_t dadd,madd,wadd,stacklevel;
	
	pc=(uint32_t *)stack[PCOFF];
	
	// Trap IRQ?
	if ((pc[-1]&(~(1<<20)))==0x73) {	// Was ECALL or EBREAK ?
		_puts("\n\n*** TRAP: ");
		_puts((pc[-1]==0x73) ? "ECALL\n" : "EBREAK\n");
		IRQEN|=ENIRQ_SSTEP;	// enable single-step
		notrace=0;
	}
	
	// Break IRQ (ctrl-C)?
	if (UARTSTA & CTRLC) {	// Was ctrl-C ?
		i=UARTDAT; 			// get ctrl-c out of UART RX
		IRQEN|=ENIRQ_SSTEP;	// and enable single-step IRQ
		notrace=0;
	}

	// hardware BRKs
	i=STATUS;
	if (i & (BRK1F | BRK2F)) {
		if (i & BRK2F) BRK2=0;	// disable temporary brk
		STATUS = BRK1F | BRK2F;	// clear flags
		IRQEN|=ENIRQ_SSTEP;	// enable single-step IRQ
		notrace=0;
	} 

	if (notrace) {	// check for breakpoints & the like
		if (stopjalr) { // Stop on subroutine returns
			if (pc[0]==0x8067) { // op: JALR X0, 0(X1)
				if (stopjalr==1) notrace=0; // any return
				else if (stack[1]>stacklevel) notrace=0; // stop if at upper stack level
					else return;
			} else return;
		} else return;
	}

	if (STATUS & SCRDTY) { // pause if the app wrote something to terminal
		_puts("\n<pause>\n");
		_getch();
	}
	
	// Interactive debug
	while (notrace==0) {
		stopjalr=0;
		
		//////////////////////////////////////////////
		//////////////// Display state ///////////////
		//////////////////////////////////////////////
		
		rn = (regnsel)? regna : regnx; // select register names
		_puts("\033[H\033[2K");	// Home, erase line
		for (i=0;i<NREG;i+=8) {
			// register names, centered
			for (j=0;j<8;j++) {
				k=_strlen((char *)rn[i+j]);
				for (l=0;l<((9-k)>>1);l++) _putch(' ');
				_puts(rn[i+j]);
				for (l+=k;l<9;l++) _putch(' ');
			}
			_puts("\n\033[2K");
			// register values (under their names)
			for (j=0;j<8;j++) {     
				if ((i+j)==0) _puts("--zero-- ");
				else _printf("%08X ",stack[i+j-1]);
			}
			_puts("\n\033[2K");
		}
		// other info (variables, registers. 2-line)
		i=BRK1;
		_printf("  %cbrk    IRQEN\n\033[2K",(i&2)?'D':' ');
		if (i&1) _printf("%08X",i&(~3));
		else _puts("--------");
		_printf("    %02X\n\033[2K\n\033[2K",IRQEN);
		// dissasembled code at PC
		//_puts("   PC\n");
		for (i=-1;i<NDIS;i++) {
			if (i==0) _puts("   PC\n\033[2K");
			j=pc[i];
			//_printf("\033[J");
			_printf("%08X: %08X  ",(uint32_t)&pc[i],j);
			dissasemble(j,(uint32_t)&pc[i]);
			_puts("\033[2K");
		}
		
		/////////////////////
		// and do commands //
		/////////////////////
docmd:		
		_puts("\n\033[2KhcsnrRbgxdmwl> ");
		i=_getch(); _putch(i);
		switch(i) {
		case 's':	// single step
			goto ssend;
			
		case 'c':	// Continue 
lcont:		IRQEN&=~ENIRQ_SSTEP;
			_puts("\033[2J\033[H");
			goto ssend;

		case 'n':	// stop on next instr
			BRK2=(uint32_t)pc + 5; // (PC+4) | 1(enable)
			goto lcont;
			
		case 'r':	// execute until Return
			notrace=1; stopjalr=1;
			goto ssend;
			
		case 'R':	// execute until Return at higher stack
			notrace=1; stopjalr=2; stacklevel=stack[1];
			goto ssend;
			
		case 'd':	// disassemble
			_putch(' ');
			if (_getsn(buf,9)) dadd=rdhex(buf);
			_putch('\n');
			for (i=dadd; i<dadd+64;i+=4) {
				j=*(uint32_t *)i;
				_printf("%08X: %08X  ",i,j);
				dissasemble(j,i);
			}
			dadd=i;
			goto docmd;
			
		case 'm':	// memory dump
			_putch(' ');
			if (_getsn(buf,9)) madd=rdhex(buf);
			_putch('\n');
			hexdump((char *)madd);
			madd+=256;
			goto docmd;

		case 'g':	// goto (set PC)
			_putch(' ');
			_putch(' '); _getsn(buf,9);
			stack[PCOFF]=rdhex(buf);
			pc=(uint32_t *)stack[PCOFF];
			break;

		case 'b':	// set breakpoint
			_putch(' ');
			if (_getsn(buf,9)) {
				i=rdhex(buf);
				BRK1=(i&(~3))+1;
			} else BRK1=0;
			break;

		case 'B':	// set data breakpoint
			_putch(' ');
			if (_getsn(buf,9)) {
				i=rdhex(buf);
				BRK1=i|3;
			} else BRK1=0;
			break;
			
		case 'x':	// change register
			_getsn(buf,3);
			i=rddec(buf);
			_putch('=');
			_getsn(buf,9);
			j=rdhex(buf);
			if (i>0 && i<32) stack[i-1]=j;
			break;
			
		case 'w':	// memory write
			_putch(' ');
			if (_getsn(buf,9)) wadd=rdhex(buf);
			_putch('\n');
			while(1){
				_printf("[%08X]=(%02X)=",wadd,*(uint8_t *)wadd);
				i=_getsn(buf,3); _putch('\n');
				if (i) {
					if (buf[0]=='-') {wadd--; continue;}
					i=rdhex(buf); *(uint8_t *)wadd++=i;
				}
				else break;
			}
			goto docmd;	
		case 'l':  // restart (Load)
			_puts("\n\n      Upload code to debug...\n\n");
			stack[PCOFF]=(uint32_t)loader;
			IRQEN=0; // no ctrl-c IRQ (ASCII 3 can be among the data)
			return;
		case 'a':  // alternate register names
			regnsel^=1;
			break;	
		case 'h': 
			help();
			goto docmd;	
						
		}
		_puts("\r\033[J");
	}
ssend:
	STATUS=SCRDTY;	// Clear dirty flag
}


// --------------------------------------------------------
// --------------------------------------------------------
// --------------------------------------------------------

// SPI transfer (8-bits)
uint32_t spixfer (uint32_t d)
{
	SPI=d;
	while(STATUS & SPIBUSY);
	return SPI;
}


void main()
{
	uint32_t i;

	IRQVECT0 = (uint32_t)debug_handler;
	VBASE = 0;		// framebuffer at the beggining of RAM
	CONTROL=MODE1 | SPIFAST | CSSD | CSPS; // 640x240, SPI fast, SPI slaves unselected
	BGCOLOR=0x01;	// dark blue
	FGCOLOR=0x3F;	// white
	DAC=2048;		// DC level
	
	// Set PSRAM in QUAD mode	
	CONTROL&=(~CSPS);
	SPI=0x35;	// enable Quad
	while (STATUS & SPIBUSY);
	CONTROL|=CSPS;

	_puts("\n\nLaRVa ][  debugger\n\n");
	_puts("J.Arias (2025)\n\n");
	_delay_ms(2000);
	
	STATUS=SCRDTY;		// clear screen dirty flag
	notrace=stopjalr=0; // just in case...
	GPOUT=0xC0;			// LED animation: starting state
	IRQEN=ENIRQ_BREAK | ENIRQ_SSTEP;	// Enable debug IRQs
	// LED animation: default code to debug 
	while(1){
		i=GPOUT; i=(i<<1)|(i>>7); GPOUT=i;
		_delay_ms(50);
	}
}

