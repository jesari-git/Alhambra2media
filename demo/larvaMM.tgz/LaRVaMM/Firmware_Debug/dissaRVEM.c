uint8_t regnsel;
const uint8_t * const regnx[32]={"X0","X1","X2","X3","X4","X5","X6","X7",
								 "X8","X9","X10","X11","X12","X13","X14","X15",
								 "X16","X17","X18","X19","X20","X21","X22","X23",
								 "X24","X25","X26","X27","X28","X29","X30","X31" };
const uint8_t * const regna[32]={"ZERO","RA","SP","GP","TP","T0","T1","T2",
								 "S0","S1","A0","A1","A2","A3","A4","A5",
								 "A6","A7","S2","S3","S4","S5","S6","S7",
								 "S8","S9","S10","S11","T3","T4","T5","T6" };

void dissasemble(uint32_t op, uint32_t pc){
	uint32_t opcode, rd, funct3, rs1, rs2, funct7, imm;
	int i;
	static const uint8_t * const rtypen[8]={"ADD   ","SLL   ","SLT   ","SLTU  ",
										    "XOR   ","SRL   ","OR    ","AND   "};
	static const uint8_t * const itype1n[8]={"ADDI  ","SLLI  ","SLTI  ","SLTIU ",
										     "XORI  ","SRLI  ","ORI   ","ANDI  "};
	static const uint8_t * const itype2n[6]={"LB    ","LH    ","LW    ","?     ",
										     "LBU   ","LHU   "};
	static const uint8_t * const stypen[3]={"SB    ","SH    ","SW    "};
	static const uint8_t * const btypen[8]={"BEQ   ","BNE   ","?     ","?     ",
										    "BLT   ","BGE   ","BLTU  ","BGEU  "};	
	static const uint8_t * const mtypen[8]={"MUL   ","MULH  ","MULHSU","MULHU ",
										    "DIV   ","DIVU  ","REM   ","REMU  "};
	uint8_t const * const *rn = (regnsel)? regna : regnx;
	opcode=op&0x7F;
	rd=(op>>7)&0x1F;
	funct3=(op>>12)&7;
	rs1=(op>>15)&0x1F;
	rs2=(op>>20)&0x1F;
	funct7=op>>25;
	imm=op>>20; if (imm&(1<<11)) imm|=0xFFFFF000;
	
	switch(opcode) {
	case 0x33:	// R-type
		if (funct7==0x20) {
			if (funct3==0) _puts("SUB   ");
			else if (funct3==0x5) _puts("SRA   ");
				else goto unk_op;
		} else {
			if (funct7==0x01) {
				_puts(mtypen[funct3]);
			} else if (funct7!=0) goto unk_op;
				else _puts(rtypen[funct3]);
		}
		_printf("  %s, %s, %s\n",rn[rd],rn[rs1],rn[rs2]);
		break;
	
	case 0x13:	// I-type (I)
		if (funct3==5 && (imm>>5)) {_puts("SRAI  "); imm&=0x1F;}
		else _puts(itype1n[funct3]);
		_printf("  %s, %s, %d\n",rn[rd],rn[rs1],imm);
		break;	
		
	case 0x03:	// I-type (II) (Load)
		if (funct3>5) goto unk_op;
		_printf("%s  %s, %d (%s)\n",itype2n[funct3],rn[rd],imm,rn[rs1]);
		break;
		
	case 0x23:	// S-type (store)
		imm=rd | ((op>>25)<<5); if (imm&(1<<11)) imm|=0xFFFFF000;
		if (funct3>2) goto unk_op;
		_printf("%s  %s, %d (%s)\n",stypen[funct3],rn[rs2],imm,rn[rs1]);
		break;
		
	case 0x63:	// B-type (branches)
		imm=(rd&0x1E) |((op>>25)&0x3F)<<5;
		if (rd&1) imm|=(1<<11);
		if (op&(1<<31)) imm|=(1<<12);
		if (imm&(1<<12)) imm|=0xFFFFE000;
		pc+=imm;
		_printf("%s  %s, %s, %08x\n",btypen[funct3],rn[rs1],rn[rs2],pc);
		break;
		
	case 0x67:	// I-type (JALR)
		_printf("JALR    %s, %d (%s)\n",rn[rd],imm,rn[rs1]);
		break;
		
	case 0x73:	// I-type (SYSTEM)
		if (op==0x30200073) {_puts("MRET\n"); break;}
		if (op==0x10200073) {_puts("SRET\n"); break;}
		if (op==0x10500073) {_puts("WFI\n"); break;}
		if (funct3==1) {_printf("CSRRW   %s, %03X, %s\n",rn[rd],imm,rn[rs1]); break;}
		_puts(imm ? "EBREAK\n" : "ECALL\n");
		break;
	
	case 0x37:	// U-type (LUI)
		_printf("LUI     %s, %05X\n",rn[rd],(op>>12));
		break;
	
	case 0x17:	// U-type (AUIPC)
		_printf("AUIPC   %s, %05X\n",rn[rd],(op>>12));
		break;
	
	case 0x6F:	// J-type (JAL)
		imm=(op&(0xff<<12)) | ((op>>20)&0x7fe);
		if(op&(1<<20)) imm|=(1<<11);
		if(op&(1<<31)) imm|=(1<<20);
		if (imm&(1<<20)) imm|=0xFFE00000;
		pc+=imm;
		if(rd) _printf("JAL     %s, %08X\n",rn[rd],pc);
		else   _printf("J       %08X\n",pc);
		break;
		
	default:
unk_op:	_puts("?     \n");
		break;
	}
}
