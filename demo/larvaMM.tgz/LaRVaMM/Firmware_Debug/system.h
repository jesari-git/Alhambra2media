///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
// LaRVa2Video_Simretro I/O register definitions & timing info
//                    J. Arias (2025)
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////

//////////////////////// Timing //////////////////////////
#define CCLK (25125000)			// CPU freq. (Hz)

void delay_loop(uint32_t val);	// (3 + 3*val) cycles (code in "Start.S")
#define _delay_us(n) delay_loop((n*(CCLK/1000)-3000)/3000)
#define _delay_ms(n) delay_loop((n*(CCLK/1000)-30)/3)

///////////////////// Peripherals ////////////////////////
//-- UART
#define UARTDAT  (*(volatile uint8_t* )0xE0000000) 
#define UARTSTA  (*(volatile uint32_t*)0xE0000004) // (RO)
// bits:
#define RXVAL	(1)		// Cleared on UARTDAT read
#define TXRDY	(2)		
#define RXFE	(4)
#define RXOVE	(8)		// Cleared on UARTDAT read
#define CTRLC	(16)	// Cleared on UARTDAT read

//-- GPIO
#define GPOUT	 (*(volatile uint8_t*)0xE0000020) // (RW)
#define GPIN	 (*(volatile uint8_t*)0xE0000021) // (RO)

//-- Control reg (RW)
#define CONTROL	 (*(volatile uint8_t*)0xE0000040)
// bits:
#define V2X      (1) 	// Video mode: Duplicate lines if 1
#define H2X      (2)	// Video mode: Duplicate pixels if 1
#define TEXT     (4)	// Video mode: Text mode if 1, graphics if 0

#define MODE0	 (0x0)	// 640x480 
#define MODE1	 (0x1)	// 640x240 
#define MODE2	 (0x2)	// 320x480 
#define MODE3	 (0x3)	// 320x240 
#define MODE4	 (0x4)	// Text, 80x60
#define MODE5	 (0x5)	// Text, 80x30
#define MODE6	 (0x6)	// Text, 40x60
#define MODE7	 (0x7)	// Text, 40x30

#define SPIFAST	 (0x8)	// SCK freq = CCLK or CCLK/256
#define CSSD	 (0x10)	// Chip select for SD card
#define CSPS	 (0x20) // Chip select for PSRAM
#define SRATE31  (0x00)	// bits [7:6]=00 => 31406 Hz (same as HSYN)
#define SRATE44  (0x40) // bits [7:6]=01 => 44100 Hz (-1.1% error)
#define SRATE48  (0x80) // bits [7:6]=1x => 48000 Hz (+2.2% error)
//-- Status REG
#define STATUS	 (*(volatile uint8_t*)0xE0000041)
// STATUS bits
#define HDE		 (1)	// also clears HDE IRQ if written with 1
#define VDE		 (2)	// also clears VDE IRQ if written with 1
#define TIMIRQ	 (4)	// (RO) cleared on TMATCH write
#define ADCIRQ	 (8)	// (RO) cleared on ADC read
#define SCRDTY	 (16)	// also clears SCRDTY flag if written with 1
#define BRK1F	 (32)	// also clears BRK1F if written with 1
#define BRK2F	 (64)	// also clears BRK1F if written with 1
#define SPIBUSY	 (128)	

//-- Timer
#define TCNT     (*(volatile uint32_t*)0xE0000060)	// (RO)
#define TMATCH   (*(volatile uint32_t*)0xE0000060)	// (WO), clears TIMIRQ

//-- Video palette (for mode #0) and base address
#define BGCOLOR	(*(volatile uint16_t*)0xE0000080) // BGR444
#define FGCOLOR	(*(volatile uint16_t*)0xE0000082) // BGR444
#define VBASE	(*(volatile uint16_t*)0xE0000084) // Video base address

//-- ADC reg (RO)
#define ADC		(*(volatile uint16_t*)0xE00000A0)
//-- DAC reg (WO)
#define DAC		(*(volatile uint16_t*)0xE00000A0)
//-- SPI2
#define SPI		(*(volatile uint8_t*)0xE00000B0)

//-- IRQ Enable reg
#define IRQEN	 (*(volatile uint8_t*)0xE00000C0)
// bits:
#define ENIRQ_HVIDEO	(1)
#define ENIRQ_VVIDEO	(2)
#define ENIRQ_UART_RX	(4)
#define ENIRQ_UART_TX	(8)
#define ENIRQ_TIMER		(16)
#define ENIRQ_ADC		(32)
#define ENIRQ_BREAK		(64)
#define ENIRQ_SSTEP		(128)

//-- Hardware breakpoints
#define BRK1	(*(volatile uint32_t*)0xE00000C8)
#define BRK2	(*(volatile uint32_t*)0xE00000CC)
// bits:
#define BRKEN	(1)
#define BRKDATA	(2)

// IRQ Vectors
// Priority order: High -   0 ,  1 ,  3 ,  6,   2 ,  4 ,   5   - Low
//                 High - Trap, HDE, URX, ADC, VDE, UTX, Timer - Low
#define IRQVECT0 (*(volatile uint32_t*)0xE00000E0)	// Trap, Break, Single-step
#define IRQVECT1 (*(volatile uint32_t*)0xE00000E4)	// Horiz. retrace
#define IRQVECT2 (*(volatile uint32_t*)0xE00000E8)	// Vert. retrace
#define IRQVECT3 (*(volatile uint32_t*)0xE00000EC)	// UART RX
#define IRQVECT4 (*(volatile uint32_t*)0xE00000F0)	// UART TX
#define IRQVECT5 (*(volatile uint32_t*)0xE00000F4)	// Timer match
#define IRQVECT6 (*(volatile uint32_t*)0xE00000F8)	// ADC
#define IRQVECT7 (*(volatile uint32_t*)0xE00000FC)	// not used


