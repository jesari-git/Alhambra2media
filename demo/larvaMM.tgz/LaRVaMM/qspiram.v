module qspiram(

// core interface
	input  clk,
	input  reset,
	input  cs,			// Memory selection
	input  [23:2]a,		// Word (32-bit) address
	input  [3:0]mwe,	// byte write enable 
	input  [31:0]di,	// data in
	output [31:0]do,	// data out
	output busy,		// controller busy => core waits

// QSPI interface
	output sck,
	output ss,
	output [3:0]qdo,	// qdo & qdi to be merged into bidirectional qio pins
	input  [3:0]qdi,
	output oe			// Output enable for bidirectional pins
);

// delayed SS to insert a cycle between reads
reg oss;
always @(negedge clk) oss<=ss;

wire busy=ibusy|start ; 

// Data size & address for writes

reg [1:0]la;	// byte address
reg [3:0]dsz;	// Data count -1 (including dummy cycles)
reg rd;			// read cycle

always @*
  casex({cs,mwe})
  5'b1_0000: {rd,dsz,la}<={1'b1,4'd13,2'b00};
  5'b1_0001: {rd,dsz,la}<={1'b0,4'd1,2'b00};
  5'b1_0010: {rd,dsz,la}<={1'b0,4'd1,2'b01};
  5'b1_0100: {rd,dsz,la}<={1'b0,4'd1,2'b10};
  5'b1_1000: {rd,dsz,la}<={1'b0,4'd1,2'b11};
  5'b1_0011: {rd,dsz,la}<={1'b0,4'd3,2'b00};
  5'b1_1100: {rd,dsz,la}<={1'b0,4'd3,2'b10};
  5'b1_1111: {rd,dsz,la}<={1'b0,4'd7,2'b00};
  default:   {rd,dsz,la}<={1'bx,4'dx,2'bxx};
  endcase

reg [3:0]maxc;	// registered size
always @(posedge clk) if (cs) maxc<=dsz;
// cycle counter
// cmd:     2 cy 
// address: 6 cy
// dummy:   6 cy (only on reads)
// data:    dsz+2
wire start=cs & ss & oss;

reg ibusy;
reg [4:0]cycnt;
always @(negedge clk or posedge reset) begin
	if (reset) ibusy<=0; else ibusy <= (start) ? 1 : (cycnt=={1'b0,maxc}) ? 0 : ibusy;
end
assign ss=~ibusy;

wire incnt = ibusy;
always @(negedge clk) 
	cycnt<= start ? 5'd24 : cycnt + incnt;
	
wire reload= (~rd)&(cycnt==5'h1F);
// "MISO" sampling on rising SCK
//reg [3:0]miso;
//always @(negedge clk) miso<=qdi; 
wire [3:0]miso=qdi;

//byte rotator
wire [31:0]bdi={di[7:0],di[15:8],di[23:16],di[31:24]}; // little endian order to big endian
wire [31:0]wdi1=la[1]? {bdi[15:0],bdi[31:16]}:bdi;		// swap halfwords
wire [31:0]wdi=la[0]? {wdi1[23:16],wdi1[31:24],wdi1[7:0],wdi1[15:8]}:wdi1; // swap bytes
// shift register (4-bits at a time)
reg [31:0]sh;
always @(negedge clk)
	sh<= start ? {rd ? 8'hEB : 8'h38,a,la} : (reload ? wdi : (ss ? sh : {sh[27:0],miso}));
assign qdo=sh[31:28];

assign do={sh[7:0],sh[15:8],sh[23:16],sh[31:24]};
assign oe=((~rd) | cycnt[4])&(~ss);
assign sck=ibusy & clk;

endmodule
